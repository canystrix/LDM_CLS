# *** LEVEL 1 - DEBUGGING *** #
# Der folgende Code enthält einige absichtlich eingebaute Fehler.
# Nutzen Sie die Traceback-Nachrichten und das PyCharm Syntax-Highlighting um diese Fehler zu finden und zu beheben!
# Erklären Sie außerdem in Kommentaren, wodurch der Fehler ausgelöst wird!
# Die Aufgabe ist erfolgreich abgeschlossen, wenn beim Ausführen des Codes keine Fehler auftreten.


# AUFGABE 1 - VARIABLEN

int = 1
float = 1.0
boolean = True
var_lambda = 11

# lambda is a Python function so can't be used as a variable; rename

sample_int = 1
sample_int = 2
sample_int != 3
# Exclamation mark should come before the equal sign
sample_int == 4
# equal operator consists of only two equal sign

sample_string = "hello world!"
sample_string = 'hello world!'
sample_string = "hello world!"
# opening and closing quotation mark must be identical
sample_string = """hello world!"""
sample_string = "hello world!"
# missing closing quotation mark
sample_string = "hello world!"
# exclamation mark should be part of the string and hence inside the quotation marks
sample_string = "hello world!"
sample_string = "hello world!"
sample_string = "hello world!"

sample_list = [1, 2, 3, 4, 5]
sample_list = [1, 2, 3, 4, 5.5]
sample_list = [1.2, 2, 03.22, 4, 5]
# closing parenthesis ')' does not match opening parenthesis '['
sample_list = [1.123, 2.434, 3.334, 4.343, 5.552]
sample_list = ["Hello", "world!"]
sample_list = ["Hello", "world!", "Nice", "to", "meet", "you!"]
sample_list = ["Hello", "world!", "Nice", "to", "meet", "you", 2, "!"]
sample_list = ["Hello", "world!", ["Nice", "to", "meet", "you", 2, "!"]]
sample_list = [["Hello", "world!"], ["Nice", "to", "meet", "you", 2, "!"]]
# one too many closing ]
sample_list = [["Hello", "world!"], ["Nice", ["to", "meet"], "you", 2, "!"]]

sample_dict = {"Hello": 1, "world!": 2}
sample_dict = {"Hello": 1, "world!": 2, "Hi": 1, "John!": 3.5}
# should be a decimal point not comma
sample_dict = {"Hello": 1, "world!": 2, "Hi": 1, "John!": 3.5}
sample_dict = {"Hello": 1, "world!": 2, "Hello": 1, "John!": 3.5}


# AUFGABE 2 - EINGEBAUTE FUNKTIONEN

# sample_int_length = len(sample_int)
# len does not work on integers
sample_string_length = len(sample_string)
sample_list_length = len(sample_list)
sample_dict_length = len(sample_dict)

print(sample_int)
print(sample_string)
# print function requires round brackets
print(sample_list)

type(sample_string)
type(sample_dict)
type(sample_string + "sample_int")
# can only concatenate str (not "int") to str


# AUFGABE 3 - EINGEBAUTE METHODEN

"Hello world!".split()
"Hello world!".split()
# ust be str or None, not int
"Hello, World".split()
# cannot split lists, only strings

[1, 2, 3, 4, 5].sort()
[1, 2, 3.3, 4, 5].sort()
[1, 2, 3.3, 4.22, 5].sort()
# sort not sorted
[1, 2, 3.3, 4.22, 5*2].sort()
["Hello", "world!"].sort()
["Hello", "world!", "Nice", "to", "meet", "you!"].sort()
["Hello", "world!", "Nice", "to", "meet", "you", "2"].sort()
["Hello", "world!", "Nice", "to", "meet", "you!", "2"].sort()
# cannot sort stg + int


# AUFGABE 4 - INDEX OPERATIONEN

sample_string[0]
# should be square rather than round brackets
sample_string[-1]
sample_string[5]
sample_string[3]
# index does not exist

sample_list[0]
sample_list[-1]
# one bracket pair too many
sample_list[1]
# index does not exist
sample_list[1]
# # index does not exist

sample_string[0:2]
sample_string[:]
# should be lowercase s
sample_string[:len(sample_string)]
# # index does not exist

sample_list[0:2]
sample_list[:]
sample_list[:len(sample_list)]