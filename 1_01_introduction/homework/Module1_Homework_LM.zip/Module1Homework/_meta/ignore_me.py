# Sieht so aus, als hätten Sie diese Datei doch nicht einfach ignorieren können aber das ist in Ordnung!
# die hier definierten Variablen werden in einer anderen Hausaufgabe verwendet.
# dazu verwenden wir ein sogenannte import statement.
# wenn Sie mehr darüber erfahren möchten, finden Sie weitere Informationen unter folgendem Link:
# https://realpython.com/python-import/


test_variable_1 = {"Hello": 1, "world": 2}
test_variable_2 = 5.55
test_variable_3 = 6
test_variable_4 = False
test_variable_5 = ["Hello", "world!"]
test_variable_6 = "Hello world!"
test_variable_7 = print()
